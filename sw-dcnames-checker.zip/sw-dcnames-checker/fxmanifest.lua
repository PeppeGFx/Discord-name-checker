fx_version 'cerulean'
game 'gta5'
lua54 'yes'
author 'PEPPEGFX'
description 'playernames'
version '1.0.0'

server_script 'server.lua'

