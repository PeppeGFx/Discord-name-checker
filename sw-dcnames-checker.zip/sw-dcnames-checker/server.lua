AddEventHandler('playerConnecting', function(playerName, setKickReason, deferrals)
    local src = source
    deferrals.defer()

    -- Wait for identifiers to be loaded
    Citizen.Wait(0)

    local discordIdentifier = nil

    -- Fetch identifiers (including Discord)
    for _, identifier in ipairs(GetPlayerIdentifiers(src)) do
        if string.match(identifier, "discord:") then
            discordIdentifier = identifier:gsub("discord:", "")
            break
        end
    end

    -- If player doesn't have Discord linked
    if not discordIdentifier then
        deferrals.done("You need to have Discord connected to join this server.")
        return
    end

    -- Inform the player that their Discord name is being verified
    deferrals.update("Verifying your Discord nickname...")

    -- Call the Node.js backend to get the player's Discord nickname and global name from the server
    PerformHttpRequest('http://34.47.203.137:40150/get-nickname', function(statusCode, response, headers)
        if statusCode == 200 then
            local data = json.decode(response)

            -- Log the response data for debugging
            print("Response Data: ", json.encode(data))

            -- Check if the data received is valid
            if data then
                local discordNickname = data.nickname
                local globalName = data.globalName

                -- Log the nickname and global name for clarity
                print("Discord Nickname: " .. tostring(discordNickname) .. ", Global Name: " .. tostring(globalName))

                -- Check if the Discord nickname is set
                if discordNickname == nil or discordNickname == "" then
                    deferrals.done("Error: You do not have a server nickname set. Please set a nickname in Discord to join.")
                    return
                end

                -- Compare in-game name and Discord server nickname (case insensitive)
                if string.lower(playerName) ~= string.lower(discordNickname) then
                    deferrals.done("Your in-game name must match your Discord server nickname. Please change your name to join.")
                    return
                end

                -- If names match, allow them to join
                deferrals.done()
            else
                -- Handle an error in the response
                deferrals.done("Error: Could not retrieve your Discord nickname. Please try again later.")
            end
        else
            -- Handle non-200 HTTP responses
            print("HTTP Error Code: ", statusCode)
            deferrals.done("Error: Could not retrieve your Discord nickname. Please try again later.")
        end
    end, 'POST', json.encode({
        discordId = discordIdentifier,
        guildId = '1214906363969282088'  -- Replace with your Discord server ID
    }), { ['Content-Type'] = 'application/json' })
end)
